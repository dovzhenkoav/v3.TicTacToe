1. Open "TIC-TAC-TOE.exe"
2. Play

made by Artemii Dovzhenko